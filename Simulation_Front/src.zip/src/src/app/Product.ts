export class Product{
    color: String = '#000000'
}